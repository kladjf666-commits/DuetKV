# Llama attention/cache ablation results

{"ok": 30, "oom": 6}

See summary.csv for per-task quality, failures and storage; performance_by_prompt.json for repeated fixed-length speed.
Failed and pending samples are retained. This is not an all-success statement.
